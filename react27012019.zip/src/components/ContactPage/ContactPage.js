import React, { Component } from "react";

// przerabiamy na class componentn
// const ContactPage = () => (
//   <div>
//     <h3>Contact Page</h3>
//     <div>
//       <h4>Lets talk!</h4>
//       <p>
//         Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lacinia
//         quam id justo hendrerit mollis. Sed feugiat erat ac tortor vehicula, et
//         gravida ante tincidunt. Quisque iaculis urna a libero consequat rutrum.
//       </p>
//       <label>Email</label>
//       <input type="text" />
//       <button>SEND</button>
//     </div>
//   </div>
// );

// export default ContactPage;

class ContactPage extends Component {
  constructor() {
    super();

    this.inputRef = React.createRef();
  }

  componentDidMount() {
    console.log("Component didmount: ", this.inputRef);
    this.inputRef.current.focus();
  }
  render() {
    console.log("Render this.inputref: ", this.inputRef);
    return (
      <div>
        <h3>Contact Page</h3>
        <div>
          <h4>Lets talk!</h4>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lacinia
            quam id justo hendrerit mollis. Sed feugiat erat ac tortor vehicula,
            et gravida ante tincidunt. Quisque iaculis urna a libero consequat
            rutrum.
          </p>
          <label>Email</label>
          <input type="text" ref={this.inputRef} />
          <button>SEND</button>
        </div>
      </div>
    );
  }
}

export default ContactPage;
